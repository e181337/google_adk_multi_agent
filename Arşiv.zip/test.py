curl -X POST "http://127.0.0.1:8000/v1/rag/query" \
  -H "Content-Type: application/json" \
  -d '{
    "question": "When should we apply enhanced due diligence?",
    "topic": "compliance",
    "country": "US",
    "top_k": 5,
    "debug": true
  }'